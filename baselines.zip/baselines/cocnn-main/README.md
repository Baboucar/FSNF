# cocnn

M. Chen, T. Ma, and X. Zhou, "CoCNN: Co-occurrence CNN for Recommendation", *Expert Systems with Applications*, Jun. 2022, 195, pp. 116595

**中文介绍：** https://snailwish.com/540/

**主要库版本：** tensorflow 1.14.0 和 pytorch 1.6.0

**Homepage:** http://zhouxiuze.com

**个人博客：** https://snailwish.com/
