# ncf-pytorch
This is a Pytorch implementation of the paper [Neural Collaborative Filtering by Xiangnan He et al](https://arxiv.org/abs/1708.05031).

This repo was inspired by the original authers' [Keras implementation](https://github.com/hexiangnan/neural_collaborative_filtering) and the Pytorch implementation [here](https://github.com/guoyang9/NCF).
