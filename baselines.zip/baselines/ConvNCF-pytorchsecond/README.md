# ConvNCF-pytorch
ConvNCF (Convolutional Neural Collaborative Filtering) model implementation in pytorch.

The ConvNCF model is proposed by:

@article{he2018outer,
  title={Outer product-based neural collaborative filtering},
  author={He, Xiangnan and Du, Xiaoyu and Wang, Xiang and Tian, Feng and Tang, Jinhui and Chua, Tat-Seng},
  journal={arXiv preprint arXiv:1808.03912},
  year={2018}
}
